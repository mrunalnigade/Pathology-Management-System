# Linkcode-Project-Group_3

(A website regarding online diagnostic center (E-Lab))

Synopsis :
Our website will consists various services provided by a pathology lab. The users will also able to register an online appointment of the lab through our portal 


To use the Git, do the following steps :-

i) Download gitbash on your device

ii) Make an Empty folder on your device

iii) Open the folder, right click and select "open gitbash here" and type "git init" in the terminal

iv) Write "git clone https://github.com/sheteshreyash/Linkcode-Project-Group_3.git" on the next line. A folder named (Linkcode-project-group3) will be downloaded in your empty folder, open it.

v) Now open that folder (linkcode-project-group3) and open gitbash (right click) there and type following commands line by line =
                                                                    *  git status ( to view the current status of git )
                                                                    *  git pull origin main ( to pull the latest changes of repo on your device )
                                                                    *  git add . ( to add your changes into the repo )
                                                                    *  git commit -m "---your msg----" ( to commit your changes into the repo )
                                                                    *  git push origin main ( to update your changes from your device on the public repo )
 

* How to delete the file in the repository :

git pull origin main 
1) type [git reset HEAD fileName]
2) type [git rm --cached -r fileName]
3) [git status]
4) [git commit -m "file deleted"]
5) [git push origin main ]
----------------------------------------------------------------------------------------------------------------------------------------------------------------
